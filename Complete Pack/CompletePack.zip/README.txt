Thank you so much for downloading my icon set. I hope you get good use out of these icons.

Included in this pack are all eleven icons for each system. I have also included the SVG source files for each icon.
If you haven't figured out by now, the special treat is an extra icon of Beck!

----------------------------------------------------------------------------------------------------------------------------

Installation Instructions:

Windows installation instructions from How to Geek. http://www.howtogeek.com/howto/13631/
For folders or shortcuts:
	1. Right click the item
	2. Select "Properties"
	3. Navigate to the "Customize" tab for folders or the "Shortcut" or "Web Document" tab for shortcuts
	4. Choose "Change Icon..."
	5. Navigate to and select the .ico file for the icon you want to use

Mac installation instructions from Apple. http://support.apple.com/kb/ht2493
For apps, folders, or files:
	1. Right click the item
	2. Select "Get Info"
	3. Drag and drop the .hqx file onto the thumbnail in the "Get Info" window

Linux icon installation may vary by distribution.
Review your distribution�s documentation and choose the proper file type for your system.
In addition to the provided PNG files, you may be able to utilize the SGV source images directly as an icon.

----------------------------------------------------------------------------------------------------------------------------

Legal stuffs:

The icons provided are fan art of the game "Mighty No. 9" in development by Comcept Inc.
I am not claiming ownership of any of the designs used, just the art style.
I do not intend to make money from the distribution of these icons.
All SVG source images are distributed under a Creative Commons: Attribution 3.0 Unported (CC BY 3.0) license.
	This means that you may make your own icon in this style, just mention me (CupricWolf) where you use it.
	For more information please visit http://creativecommons.org/licenses/by/3.0/
	Please note that the designs used in the source images are Comcept's.
